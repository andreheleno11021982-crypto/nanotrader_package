import React from 'react';
import { View, Text } from 'react-native';

export default function CandleChartWithSignals({ candles, signals }) {
  return (
    <View style={{height:320, justifyContent:'center', alignItems:'center'}}>
      <Text>Gráfico placeholder — substitua por biblioteca de candles</Text>
      {signals && signals.map((s, i) => (
        <Text key={i}>{s.type} @{s.index} ({(s.conf*100||0).toFixed(0)}%)</Text>
      ))}
    </View>
  );
}
