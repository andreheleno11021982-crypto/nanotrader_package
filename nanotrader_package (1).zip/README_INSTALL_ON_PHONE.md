## Como instalar o APK no Android (no celular)
1. Baixe o APK do artifact no GitHub (veja README principal).
2. Se aparecer aviso de segurança, vá em Configurações -> Apps e permissões -> Instalar apps desconhecidos -> permita no navegador/gestor de arquivos.
3. Toque no APK para instalar.
4. Abra o app.
