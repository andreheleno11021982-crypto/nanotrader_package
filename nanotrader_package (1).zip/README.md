# NanoTrader - APK build package (debug)

This package contains a ready React Native project skeleton for **NanoTrader**,
a placeholder TFLite model, and a GitHub Actions workflow that builds an Android
debug APK (`app-debug.apk`) and uploads it as an artifact.

**Important limitations**
- I cannot run builds or host APKs from here. This package is for you to upload
  to a **GitHub repository** (using GitHub mobile or desktop). Once pushed, the
  provided GitHub Actions workflow will run on GitHub's servers and produce an
  APK artifact you can download directly on your phone.
- The included `model.tflite` is a placeholder. Replace it with your real `.tflite`
  before running builds.

## Quick steps to get the APK (from your phone)
1. Create a new GitHub repository (via GitHub mobile app or web).
2. Upload the contents of this ZIP into the repository (you can upload the ZIP and
   extract, or upload files one-by-one).
3. Go to the repository's **Actions** tab. The workflow `android-build.yml` should
   run automatically on push. Wait for it to finish.
4. Open the finished workflow run → **Artifacts** → download `nanotrader-app-debug-apk`.
   Save and open the APK on your phone to install.

## If you prefer, I can also:
- Provide full source files to paste into an existing project.
- Guide you step-by-step via chat for each GitHub mobile action.

